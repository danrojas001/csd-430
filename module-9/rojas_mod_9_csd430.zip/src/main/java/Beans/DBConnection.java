// Dan Rojas
// Mod 9.2
// 26-Jul-26

package Beans;

import java.sql.*;

public class DBConnection implements java.io.Serializable {

    Connection conn;
    Statement stmt;

    /*
    **********
    CONNECT TO THE DATABASE
    **********
     */
    public DBConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in constructor.");
            e.printStackTrace();
        }
    }

    /*
    **********
    CREATE FORM FOR TABLE RECORD SELECTION
    **********
     */
    public String formGetPK(String requestURL) {
        java.sql.ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in formGetPK().");
            e.printStackTrace();
        }

        try {
            rs = stmt.executeQuery("SELECT isbn FROM dan_library_data");
        } catch (java.sql.SQLException e) {
            System.out.println("Error querying ISBN numbers in formGetPK().");
            e.printStackTrace();
        }

        StringBuilder dataStringBuilder = new StringBuilder();
        dataStringBuilder.append("<form method='post' action='" + requestURL + "'>\n");
        dataStringBuilder.append("<br /> \n");
        dataStringBuilder.append("<label for='isbn'>Select an ISBN:</label>\n");
        dataStringBuilder.append("<select name='isbnDropdown' id='isbn'>\n");

        try {
            while (rs.next()) {
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    dataStringBuilder.append("<option value=\"");
                    dataStringBuilder.append((rs.getString(i)));
                    dataStringBuilder.append("\">\n");
                    dataStringBuilder.append((rs.getString(i)));
                    dataStringBuilder.append("</option>");
                }
            }
        } catch (Exception e) {
            System.out.println("Error creating dropdown in formGetPK().");
            e.printStackTrace();
        }

        dataStringBuilder.append("</select>");

        dataStringBuilder.append("<input type='hidden' name='action' value='submit'/>\n");
        dataStringBuilder.append("<input type='submit' value='submit'/>\n");
        dataStringBuilder.append("</form>");

        return dataStringBuilder.toString();
    }

    /*
    **********
    CREATE TABLE WITH HEADERS FOR DISPLAY OF SELECTED ISBN ASSOCIATED RECORD
    **********
     */
    public String read(String isbn) {
        StringBuilder dataStringBuilder = new StringBuilder();
        java.sql.ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in read().");
            e.printStackTrace();
        }

        try {
            rs = stmt.executeQuery("SELECT * FROM dan_library_data WHERE isbn = " + isbn);
        } catch (java.sql.SQLException e) {
            System.out.println("Error querying user selected isbn in read().");
            e.printStackTrace();
        }

        try {
            java.sql.ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            dataStringBuilder.append("<table border='1' bgcolor='f77f00'>");
            dataStringBuilder.append("<thead><tr>");
            for (int i = 1; i <= columnCount; i++) {
                dataStringBuilder.append("<th>");
                dataStringBuilder.append(rsmd.getColumnName(i));
                dataStringBuilder.append("</th>");
            }
            dataStringBuilder.append("</tr></thead>");
            dataStringBuilder.append("<tbody>");

            while (rs.next()) {
                dataStringBuilder.append("<tr>");
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    dataStringBuilder.append("<td>");
                    dataStringBuilder.append((rs.getString(i)).trim());
                    dataStringBuilder.append("</td>");
                }
                dataStringBuilder.append("</tr>");
            }
            dataStringBuilder.append("</tbody>");
            dataStringBuilder.append("</table>");
        } catch (Exception e) {
            System.out.println("Error creating <tr> for selected record in read().");
            e.printStackTrace();
        }

        return dataStringBuilder.toString();
    }

    /*
    **********
    DISPLAY ALL RECORDS IN TABLE WITH HEADERS
    **********
     */
    public String readAll() {

        StringBuilder dataStringBuilder = new StringBuilder();
        java.sql.ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in readAll().");
            e.printStackTrace();
        }

        try {
            rs = stmt.executeQuery("SELECT * FROM dan_library_data");
        } catch (java.sql.SQLException e) {
            System.out.println("Error querying all data from table in readAll().");
            e.printStackTrace();
        }

        try {
            java.sql.ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            dataStringBuilder.append("<table border='1' bgcolor='fcbf49'>");
            dataStringBuilder.append("<thead><tr>");
            for (int i = 1; i <= columnCount; i++) {
                dataStringBuilder.append("<th>");
                dataStringBuilder.append(rsmd.getColumnName(i));
                dataStringBuilder.append("</th>");
            }
            dataStringBuilder.append("</tr></thead>");
            dataStringBuilder.append("<tbody>");
            while (rs.next()) {
                dataStringBuilder.append("<tr>");
                for (int i = 1; i <= columnCount; i++) {

                    dataStringBuilder.append("<td>");
                    dataStringBuilder.append((rs.getString(i)).trim());
                    dataStringBuilder.append("</td>");
                }
                dataStringBuilder.append("</tr>");
            }
            dataStringBuilder.append("</tbody>");
            dataStringBuilder.append("</table>");
        } catch (Exception e) {
            System.out.println("Error creating <table> for all data in readAll().");
            e.printStackTrace();
        }

        return dataStringBuilder.toString();
    }

    /*
    **********
    CREATE FORM FOR TABLE RECORD CREATION
    **********
     */
    public String formGetCreate(String requestURL) {
        StringBuilder dataStringBuilder = new StringBuilder();
        java.sql.ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in formGetCreate().");
            e.printStackTrace();
        }

        try {
            dataStringBuilder.append("<form method='post' action='" + requestURL + "'>\n");
            dataStringBuilder.append("<table> <tbody>\n");
            dataStringBuilder.append("<br /> \n");

            // ISBN input
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='isbnText'>Input new ISBN:</label> </td>\n");
            dataStringBuilder.append("<td> <input type='text' name='isbnText' value='' " +
                    "pattern=\"[0-9]{10,13}\" placeholder='13 digit number' required> </td>\n");
            dataStringBuilder.append("</tr>\n");

            // title input
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='titleText'>input book's title:</label> </td>\n");
            dataStringBuilder.append("<td><input type='text' name='titleText' value='' " +
                    "pattern=\"[A-Za-z0-9\\s.,':!?()-]+\" required></td>\n"
            );
            dataStringBuilder.append("</tr>\n");

            // author input
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='authorText'>Input author's name:</label> </td>\n");
            dataStringBuilder.append("<td> <input type='text' name='authorText' value='' " +
                    "pattern=\"[A-Za-z' \\-]{2,100}\" required> </td>\n");
            dataStringBuilder.append("</tr>\n");

            // date input
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='datePicker'>Input published date:</label> </td>\n");
            dataStringBuilder.append("<td> <input type='date' name='datePicker' required> </td>\n");
            dataStringBuilder.append("</tr>\n");

            // genre input
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='genreText'>Input genre:</label> </td>\n");
            dataStringBuilder.append("<td> <input type='text' name='genreText' value='' " +
                    "pattern=\"[A-Za-z' \\-]{2,50}\" required> </td>\n");
            dataStringBuilder.append("</tr>\n");

            dataStringBuilder.append("</tbody> </table>\n");
            dataStringBuilder.append("<input type='submit' value='Submit'>\n");
            dataStringBuilder.append("</form>\n");
        } catch (Exception e) {
            System.out.println("Error creating input <form> in formGetCreate().");
            e.printStackTrace();
        }


        return dataStringBuilder.toString();
    }

    /*
    **********
    CREATE NEW TABLE RECORD
    **********
     */
    public boolean createRecord(String isbn, String title, String author, Date publishDate, String genre) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in formGetCreate().");
            e.printStackTrace();
        }

        if (validateISBN(isbn)) {
            try {
                String sql = "INSERT INTO dan_library_data(isbn, title, author, publishDate, genre) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setString(1, isbn);
                pst.setString(2, title);
                pst.setString(3, author);
                pst.setDate(4, new Date(publishDate.getTime()));
                pst.setString(5, genre);
                pst.executeUpdate();

                return true; // insert successful
            } catch (SQLException e) {
                System.out.println("Error in createRecord().");
                e.printStackTrace();
                return false;
            }
        }
        return false;
    }

    /*
    **********
    VERIFY ISBN DOES NOT ALREADY EXIST IN TABLE
    **********
     */
    public boolean validateISBN(String isbn) {

        try {
            String checkStmt = "SELECT isbn FROM dan_library_data WHERE isbn = ?";

            PreparedStatement checkPstmt = conn.prepareStatement(checkStmt);
            checkPstmt.setString(1, isbn);

            ResultSet rs = checkPstmt.executeQuery();

            return !rs.next(); //ISBN does not exist in table

        } catch (SQLException e) {
            System.out.println("Error validating isbn in validateISBN().");
            e.printStackTrace();
        }
        return false;
    }

    /*
    **********
    ALERT USER ISBN ALREADY EXISTS IN TABLE
    **********
     */
    public String isbnExistsAlert(String isbn) {
        StringBuilder alert = new StringBuilder();
        alert.append("<a href=\"CRUD_CREATE.jsp\">CRUD - CREATE</a>");
        alert.append("<p>ISBN - " + isbn + " ALREADY EXISTS IN TABLE</p>\n");

        return alert.toString();
    }

    /*
    **********
    CREATE FORM FOR TABLE RECORD UPDATE
    **********
     */
    public String formGetUpdate(String requestURL, String isbn) {
        StringBuilder dataStringBuilder = new StringBuilder();
        java.sql.ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in formGetUpdate().");
            e.printStackTrace();
        }

        try {
            dataStringBuilder.append("<form method='post' action='" + requestURL + "'>\n");
            dataStringBuilder.append("<table> <tbody>\n");
            dataStringBuilder.append("<br /> \n");

            // ISBN display
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='isbnText'>Chosen ISBN:</label> </td>\n");
            dataStringBuilder.append("<td> <input type='text' name='isbnText' value='" + isbn + "' readonly " +
                    "style='background-color: #e9e9e9'> </td>\n");
            dataStringBuilder.append("</tr>\n");

            // title input
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='titleText'>input book's title:</label> </td>\n");
            dataStringBuilder.append("<td><input type='text' name='titleText' value='' " +
                    "pattern=\"[A-Za-z0-9\\s.,':!?()-]+\" required></td>\n"
            );
            dataStringBuilder.append("</tr>\n");

            // author input
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='authorText'>Input author's name:</label> </td>\n");
            dataStringBuilder.append("<td> <input type='text' name='authorText' value='' " +
                    "pattern=\"[A-Za-z' \\-]{2,100}\" required> </td>\n");
            dataStringBuilder.append("</tr>\n");

            // date input
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='datePicker'>Input published date:</label> </td>\n");
            dataStringBuilder.append("<td> <input type='date' name='datePicker' required> </td>\n");
            dataStringBuilder.append("</tr>\n");

            // genre input
            dataStringBuilder.append("<tr> \n");
            dataStringBuilder.append("<td> <label for='genreText'>Input genre:</label> </td>\n");
            dataStringBuilder.append("<td> <input type='text' name='genreText' value='' " +
                    "pattern=\"[A-Za-z' \\-]{2,50}\" required> </td>\n");
            dataStringBuilder.append("</tr>\n");

            dataStringBuilder.append("</tbody> </table>\n");
            dataStringBuilder.append("<input type='hidden' name='action' value='update'>\n");
            dataStringBuilder.append("<input type='submit' value='update'>\n");
            dataStringBuilder.append("</form>\n");
        } catch (Exception e) {
            System.out.println("Error creating input <form> in formGetUpdate().");
            e.printStackTrace();
        }

        return dataStringBuilder.toString();
    }

    /*
    **********
    UPDATES SELECTED RECORD
    **********
     */
    public boolean updateRecord(String isbn, String title, String author, Date publishDate, String genre) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in updateRecord().");
            e.printStackTrace();
        }

        try {
            String sql = "UPDATE dan_library_data SET title = ?, author = ?, publishDate = ?, genre = ? WHERE isbn = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, title);
            pst.setString(2, author);
            pst.setDate(3, new Date(publishDate.getTime()));
            pst.setString(4, genre);
            pst.setString(5, isbn);
            pst.executeUpdate();

            return true; // update successful
        } catch (SQLException e) {
            System.out.println("Error in updateRecord().");
            e.printStackTrace();
            return false;
        }
    }

    /*
    **********
    DELETES THE SELECTED RECORD
    **********
     */
    public void deleteRecord(String isbn) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in deleteRecord().");
            e.printStackTrace();
        }

        try {
            String sql = "DELETE FROM dan_library_data WHERE isbn = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, isbn);
            pst.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error in deleteRecord().");
            e.printStackTrace();
        }
    }

    /*
    **********
    CLOSE CONNECTION TO DATABASE
    **********
     */
    public void closeConnection() {
        try {
            stmt.close();
            conn.close();
            System.out.println("Database connections closed");
        } catch (SQLException e) {
            System.out.println("Error closing connection to database.");
            e.printStackTrace();
        }
    }

}
