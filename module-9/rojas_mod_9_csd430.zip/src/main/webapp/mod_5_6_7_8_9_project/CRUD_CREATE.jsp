<%@ page import="Beans.DBConnection" %>
<%@ page import="java.sql.Date" %>

<%--
Dan Rojas
Mod 5.3 & 6.3
12-Jul-26
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Dan's Library Table Record Creation</title>
</head>
<body>
<h1>Dan's Library Table Record Creation</h1>
<a href="project-index.jsp">BACK TO HOME</a>
<%
    // create and display form for new record creation
    if (request.getMethod().equals("GET")) {
        DBConnection myDB = new DBConnection();
        String form = myDB.formGetCreate("CRUD_CREATE.jsp");
        out.print(form);
        myDB.closeConnection();
    }

    if (request.getMethod().equals("POST")) {
        DBConnection myDB = new DBConnection();
        boolean result = myDB.createRecord(request.getParameter("isbnText"),
                request.getParameter("titleText"),
                request.getParameter("authorText"),
                Date.valueOf(request.getParameter("datePicker")),
                request.getParameter("genreText"));

        if (result) {
            // display the newly created record by passing its ISBN
            out.print(myDB.read(request.getParameter("isbnText")));
            out.println("<br />");
            // display all records in table
            out.print(myDB.readAll());
        } else {
            // display message regarding existing ISBN
            out.print(myDB.isbnExistsAlert(request.getParameter("isbnText")));
            out.println("<br />");
            // display all records in table
            out.print(myDB.readAll());
        }

        myDB.closeConnection();

    }
%>
</body>
</html>
