

<%--
Dan Rojas
Mod 5.3 & 6.3
05-Jul-26
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Crud Project Home</title>
</head>
<body>
<ul>
    <h1>Crud Project Home</h1>
    <li>
        <a href="CRUD_READ.jsp">CRUD - READ</a>
    </li>
    <li>
        <a href="CRUD_CREATE.jsp">CRUD - CREATE</a>
    </li>
    <li>
        <a href="CRUD_UPDATE.jsp">CRUD - UPDATE</a>
    </li>
    <li>
        <a href="CRUD_DELETE.jsp">CRUD - DELETE</a>
    </li>
</ul>
</body>
</html>
