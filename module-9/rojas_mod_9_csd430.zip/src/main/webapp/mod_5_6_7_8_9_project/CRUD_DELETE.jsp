<%@ page import="Beans.DBConnection" %>

<%--
Dan Rojas
Mod 9.2
26-Jul-26
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Dan's Library Record Delete</title>
</head>
<body>
<h1>Dan's Library Record Delete</h1>
<a href="project-index.jsp">BACK TO HOME</a>
<%
    // create and display form for pk selection
    if (request.getMethod().equals("GET")) {
        DBConnection myDB = new DBConnection();
        out.print(myDB.formGetPK("CRUD_DELETE.jsp"));
        out.print(myDB.readAll());
        myDB.closeConnection();
    }


    if (request.getMethod().equals("POST")) {
        DBConnection myDB = new DBConnection();
        String isbn = request.getParameter("isbnDropdown");
        myDB.deleteRecord(isbn);
        out.print(myDB.formGetPK("CRUD_DELETE.jsp"));
        out.println("<br />");
        // display all remaining records in table
        out.print(myDB.readAll());
        myDB.closeConnection();
    }
%>

</body>
</html>
