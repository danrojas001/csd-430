

<%--
Dan Rojas
Mod 5.3 & 6.3
05-Jul-26
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Crud Project Home</title>
</head>
<body>
<ul>
    <h1>Crud Project Home</h1>
    <li>
        <a href="CRUD_READ.jsp">CRUD - READ</a>
    </li>
</ul>
</body>
</html>
