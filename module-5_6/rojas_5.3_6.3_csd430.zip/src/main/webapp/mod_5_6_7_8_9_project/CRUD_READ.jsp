<%@ page import="Beans.DBConnection" %>

<%--
Dan Rojas
Mod 5.3 & 6.3
05-Jul-26
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Dan's Library Table Search</title>
</head>
<body>
<h1>Dan's Library Table Search</h1>
<%
    // create and display form for ISBN selection
    if (request.getMethod().equals("GET")) {
        DBConnection myDB = new DBConnection();
        myDB.formGetPK("CRUD_READ.jsp");
        String form = myDB.formGetPK("CRUD_READ.jsp");
        out.print(form);
        myDB.closeConnection();
    }

    if (request.getMethod().equals("POST")) {
        DBConnection myDB = new DBConnection();
        out.print(myDB.formGetPK("CRUD_READ.jsp"));
        String isbn = request.getParameter("isbnDropdown");
        // display selected ISBN's record
        out.print(myDB.read(isbn));
        out.println("<br />");
        // display all records in table
        out.print(myDB.readAll());
        myDB.closeConnection();
    }
%>
</body>
</html>
