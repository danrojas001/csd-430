<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<!DOCTYPE html>
<html>
<body>
<ul>
    <h1>Home</h1>
    <li>
        <a href="mod_1/test.jsp">mod_1</a>
    </li>
    <li>
        <a href="mod_2/mod2_2.jsp">mod_2</a>
    </li>
    <li>
        <a href="mod_3/form.jsp">mod_3</a>
    </li>
    <li>
        <a href="mod_4/mod4_2.jsp">mod_4</a>
    </li>
    <li>
        <a href="mod_5_6_7_8_9_project/project-index.jsp">mod_5_6_7_8_9_project</a>
    </li>
</ul>
</body>
</html>
