// Dan Rojas
// Mod 5.2 & 6.2
// 05-Jul-26

package Beans;

import java.sql.*;

public class DBConnection implements java.io.Serializable {

    Connection conn;
    Statement stmt;

    /*
    **********
    CONNECT TO THE DATABASE
    **********
     */
    public DBConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in constructor.");
            e.printStackTrace();
        }
    }

    /*
    **********
    CREATE FORM FOR TABLE RECORD SELECTION
    **********
     */
    public String formGetPK(String requestURL) {
        java.sql.ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in formGetPK().");
            e.printStackTrace();
        }

        try {
            rs = stmt.executeQuery("SELECT isbn FROM dan_library_data");
        } catch (java.sql.SQLException e) {
            System.out.println("Error querying ISBN numbers in formGetPK().");
            e.printStackTrace();
        }

        StringBuilder dataStringBuilder = new StringBuilder();
        dataStringBuilder.append("<form method='post' action='" + requestURL + "'>\n");
        dataStringBuilder.append("<br /> \n");
        dataStringBuilder.append("<label for='isbn'>Select an ISBN:</label>\n");
        dataStringBuilder.append("<select name='isbnDropdown' id='isbn'>\n");

        try {
            while (rs.next()) {
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    dataStringBuilder.append("<option value=\"");
                    dataStringBuilder.append((rs.getString(i)));
                    dataStringBuilder.append("\">\n");
                    dataStringBuilder.append((rs.getString(i)));
                    dataStringBuilder.append("</option>");
                }
            }
        } catch (Exception e) {
            System.out.println("Error creating dropdown in formGetPK().");
            e.printStackTrace();
        }

        dataStringBuilder.append("</select>");
        dataStringBuilder.append("<input type='submit'/>");
        dataStringBuilder.append("</form>");

        return dataStringBuilder.toString();
    }

    /*
    **********
    CREATE TABLE WITH HEADERS FOR DISPLAY OF SELECTED ISBN ASSOCIATED RECORD
    **********
     */
    public String read(String isbn) {
        StringBuilder dataStringBuilder = new StringBuilder();
        java.sql.ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in read().");
            e.printStackTrace();
        }

        try {
            rs = stmt.executeQuery("SELECT * FROM dan_library_data WHERE isbn = " + isbn);
        } catch (java.sql.SQLException e) {
            System.out.println("Error querying user selected isbn in read().");
            e.printStackTrace();
        }

        try {
            java.sql.ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            dataStringBuilder.append("<table border='1' bgcolor='f77f00'>");
            dataStringBuilder.append("<thead><tr>");
            for (int i = 1; i <= columnCount; i++) {
                dataStringBuilder.append("<th>");
                dataStringBuilder.append(rsmd.getColumnName(i));
                dataStringBuilder.append("</th>");
            }
            dataStringBuilder.append("</tr></thead>");
            dataStringBuilder.append("<tbody>");

            while (rs.next()) {
                dataStringBuilder.append("<tr>");
                for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
                    dataStringBuilder.append("<td>");
                    dataStringBuilder.append((rs.getString(i)).trim());
                    dataStringBuilder.append("</td>");
                }
                dataStringBuilder.append("</tr>");
            }
            dataStringBuilder.append("</tbody>");
            dataStringBuilder.append("</table>");
        } catch (Exception e) {
            System.out.println("Error creating <tr> for selected record in read().");
            e.printStackTrace();
        }

        return dataStringBuilder.toString();
    }

    /*
    **********
    DISPLAY ALL RECORDS IN TABLE WITH HEADERS
    **********
     */
    public String readAll() {

        StringBuilder dataStringBuilder = new StringBuilder();
        java.sql.ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/csd430";
            String user = "student1";
            String password = "pass";
            conn = DriverManager.getConnection(url, user, password);
            stmt = conn.createStatement();
        } catch (Exception e) {
            System.out.println("Error connecting to database in readAll().");
            e.printStackTrace();
        }

        try {
            rs = stmt.executeQuery("SELECT * FROM dan_library_data");
        } catch (java.sql.SQLException e) {
            System.out.println("Error querying all data from table in readAll().");
            e.printStackTrace();
        }

        try {
            java.sql.ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            dataStringBuilder.append("<table border='1' bgcolor='fcbf49'>");
            dataStringBuilder.append("<thead><tr>");
            for (int i = 1; i <= columnCount; i++) {
                dataStringBuilder.append("<th>");
                dataStringBuilder.append(rsmd.getColumnName(i));
                dataStringBuilder.append("</th>");
            }
            dataStringBuilder.append("</tr></thead>");
            dataStringBuilder.append("<tbody>");
            while (rs.next()) {
                dataStringBuilder.append("<tr>");
                for (int i = 1; i <= columnCount; i++) {

                    dataStringBuilder.append("<td>");
                    dataStringBuilder.append((rs.getString(i)).trim());
                    dataStringBuilder.append("</td>");
                }
                dataStringBuilder.append("</tr>");
            }
            dataStringBuilder.append("</tbody>");
            dataStringBuilder.append("</table>");
        } catch (Exception e) {
            System.out.println("Error creating <table> for all data in readAll().");
            e.printStackTrace();
        }

        return dataStringBuilder.toString();
    }

    /*
    **********
    CLOSE CONNECTION TO DATABASE
    **********
     */
    public void closeConnection() {
        try {
            stmt.close();
            conn.close();
            System.out.println("Database connections closed");
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error closing connection to database.");
        }
    }

}
