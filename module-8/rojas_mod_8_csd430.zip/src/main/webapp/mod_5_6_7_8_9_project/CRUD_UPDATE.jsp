<%@ page import="Beans.DBConnection" %>
<%@ page import="java.sql.Date" %>

<%--
Dan Rojas
Mod 5.3 & 6.3
19-Jul-26
--%>

<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Dan's Library Table Record Update</title>
</head>
<body>
<h1>Dan's Library Table Record Update</h1>
<%
    // create and display form for pk selection
    if (request.getMethod().equals("GET")) {
        DBConnection myDB = new DBConnection();
        String form = myDB.formGetPK("CRUD_UPDATE.jsp");
        out.print(form);
        myDB.closeConnection();
    }

    if (request.getMethod().equals("POST")) {
        DBConnection myDB = new DBConnection();
        String action = request.getParameter("action");

        if ("load".equals(action)) { // loads update form
            String isbn = request.getParameter("isbnDropdown");
            out.print(myDB.formGetUpdate("CRUD_UPDATE.jsp", isbn));
        } else if ("update".equals(action)) { // updates record and displays new update and full table
            myDB.updateRecord(request.getParameter("isbnText"),
                request.getParameter("titleText"),
                request.getParameter("authorText"),
                Date.valueOf(request.getParameter("datePicker")),
                request.getParameter("genreText"));
                // display updated ISBN's record
                out.print(myDB.read(request.getParameter("isbnText")));
                out.println("<br />");
                // display all records in table
                out.print(myDB.readAll());
        }
    }
%>

</body>
</html>
